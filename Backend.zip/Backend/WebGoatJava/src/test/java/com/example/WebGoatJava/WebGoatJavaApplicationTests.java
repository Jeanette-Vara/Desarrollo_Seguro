package com.example.WebGoatJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebGoatJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
